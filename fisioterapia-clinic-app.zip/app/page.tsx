"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { storage } from "@/lib/storage"

export default function HomePage() {
  const router = useRouter()

  useEffect(() => {
    if (storage.isAuthenticated()) {
      router.push("/dashboard")
    } else {
      router.push("/login")
    }
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-muted-foreground">Carregando...</p>
    </div>
  )
}
