"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Search, FileText, Calendar, Users, Activity, Eye, Trash2, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { storage } from "@/lib/storage"
import type { Patient } from "@/types/patient"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

export default function HistoryPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [patients, setPatients] = useState<Patient[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filter, setFilter] = useState<"todos" | "ativos" | "concluidos">("todos")
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; patientId: string; patientName: string }>({
    open: false,
    patientId: "",
    patientName: "",
  })
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    if (!storage.isAuthenticated()) {
      router.push("/login")
      return
    }

    setPatients(storage.getPatients())
    setIsAdmin(storage.isAdmin())
  }, [router])

  const handleDeleteClick = (patient: Patient) => {
    setDeleteDialog({
      open: true,
      patientId: patient.id,
      patientName: patient.name,
    })
  }

  const handleConfirmDelete = () => {
    storage.deletePatient(deleteDialog.patientId)
    setPatients(storage.getPatients())

    toast({
      title: "Paciente excluído",
      description: `${deleteDialog.patientName} foi removido do sistema com sucesso`,
      variant: "destructive",
    })

    setDeleteDialog({ open: false, patientId: "", patientName: "" })
  }

  const filteredPatients = patients.filter((patient) => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter =
      filter === "todos" ||
      (filter === "ativos" && patient.completedSessions < patient.totalSessions) ||
      (filter === "concluidos" && patient.completedSessions >= patient.totalSessions)
    return matchesSearch && matchesFilter
  })

  const totalAtendimentos = patients.reduce((sum, p) => sum + p.sessions.length, 0)
  const sessoesRealizadas = patients.reduce((sum, p) => sum + p.completedSessions, 0)
  const pacientesAtendidos = patients.length
  const tratamentosAtivos = patients.filter((p) => p.completedSessions < p.totalSessions).length

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#faf8f5] via-[#f5f1ec] to-[#ede7e0]">
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div className="flex items-center gap-2 ml-4">
              <div className="w-10 h-10 bg-gradient-to-br from-[#9b2847] to-[#b8385d] rounded-lg flex items-center justify-center shadow-md">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">Histórico de Pacientes</h1>
                <p className="text-sm text-gray-500">Visualize todos os pacientes e seus tratamentos</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {!isAdmin && (
          <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg shadow-sm">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Eye className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900">Visualização do Histórico</h3>
                <p className="text-sm text-blue-700 mt-1">
                  Você pode visualizar todos os dados dos pacientes e acessar seus detalhes. Apenas administradores
                  podem excluir pacientes do sistema.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <p className="text-sm text-gray-600 font-medium">Total de Atendimentos</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{totalAtendimentos}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-md">
                <FileText className="w-6 h-6 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <p className="text-sm text-gray-600 font-medium">Sessões Realizadas</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{sessoesRealizadas}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center shadow-md">
                <Activity className="w-6 h-6 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <p className="text-sm text-gray-600 font-medium">Tratamentos Ativos</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{tratamentosAtivos}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-teal-600 rounded-lg flex items-center justify-center shadow-md">
                <Calendar className="w-6 h-6 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <p className="text-sm text-gray-600 font-medium">Total de Pacientes</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{pacientesAtendidos}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center shadow-md">
                <Users className="w-6 h-6 text-white" />
              </div>
            </CardHeader>
          </Card>
        </div>

        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50/30 border-b">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <CardTitle className="text-xl text-gray-900">Histórico Completo</CardTitle>
              <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto">
                <div className="relative flex-1 md:w-80">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Buscar paciente..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 h-11 border-gray-200 focus:border-[#9b2847] focus:ring-[#9b2847]"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={filter === "todos" ? "default" : "outline"}
                    onClick={() => setFilter("todos")}
                    className={
                      filter === "todos"
                        ? "bg-gradient-to-r from-[#9b2847] to-[#b8385d] hover:from-[#7a1f38] hover:to-[#9b2847]"
                        : "bg-transparent hover:bg-gray-50"
                    }
                  >
                    Todos
                  </Button>
                  <Button
                    variant={filter === "ativos" ? "default" : "outline"}
                    onClick={() => setFilter("ativos")}
                    className={
                      filter === "ativos"
                        ? "bg-gradient-to-r from-[#9b2847] to-[#b8385d] hover:from-[#7a1f38] hover:to-[#9b2847]"
                        : "bg-transparent hover:bg-gray-50"
                    }
                  >
                    Ativos
                  </Button>
                  <Button
                    variant={filter === "concluidos" ? "default" : "outline"}
                    onClick={() => setFilter("concluidos")}
                    className={
                      filter === "concluidos"
                        ? "bg-gradient-to-r from-[#9b2847] to-[#b8385d] hover:from-[#7a1f38] hover:to-[#9b2847]"
                        : "bg-transparent hover:bg-gray-50"
                    }
                  >
                    Concluídos
                  </Button>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-2">
              Mostrando {filteredPatients.length} de {patients.length} pacientes
            </p>
          </CardHeader>
          <CardContent className="p-6">
            {filteredPatients.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-10 h-10 text-gray-400" />
                </div>
                <p className="text-lg font-medium">Nenhum paciente encontrado</p>
                <p className="text-sm mt-1">Tente ajustar os filtros ou o termo de busca</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredPatients.map((patient) => {
                  const progress = (patient.completedSessions / patient.totalSessions) * 100
                  const isCompleted = patient.completedSessions >= patient.totalSessions

                  return (
                    <Card key={patient.id} className="border-0 shadow-md hover:shadow-lg transition-all duration-300">
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          <div className="flex-shrink-0">
                            <div className="w-14 h-14 bg-gradient-to-br from-[#9b2847] to-[#b8385d] rounded-lg flex items-center justify-center shadow-md">
                              <span className="text-white font-bold text-xl">{patient.name.charAt(0)}</span>
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-4 mb-3">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <Badge
                                    className={
                                      isCompleted
                                        ? "bg-gradient-to-r from-green-100 to-green-200 text-green-800 border-0 hover:from-green-200 hover:to-green-300"
                                        : "bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 border-0 hover:from-blue-200 hover:to-blue-300"
                                    }
                                  >
                                    {isCompleted ? "Concluído" : "Ativo"}
                                  </Badge>
                                  <span className="text-sm text-gray-500 font-medium">
                                    {patient.completedSessions}/{patient.totalSessions} sessões
                                  </span>
                                </div>
                                <h3 className="text-lg font-bold text-gray-900">{patient.name}</h3>
                                <p className="text-sm text-gray-600 mt-1">CPF: {patient.cpf}</p>
                              </div>
                              <div className="flex gap-2">
                                <Link href={`/dashboard/paciente/${patient.id}`}>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="bg-white border-[#9b2847] text-[#9b2847] hover:bg-[#9b2847] hover:text-white transition-all"
                                  >
                                    <Eye className="w-4 h-4 mr-2" />
                                    Visualizar
                                  </Button>
                                </Link>
                                {isAdmin && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="bg-white border-red-300 hover:bg-red-50 hover:border-red-400 text-red-600 transition-all"
                                    onClick={() => handleDeleteClick(patient)}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </div>

                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600 font-medium">Progresso do tratamento</span>
                                <span className="font-bold text-gray-900">{Math.round(progress)}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2.5 shadow-inner">
                                <div
                                  className="bg-gradient-to-r from-[#9b2847] via-[#b8385d] to-[#c54a6f] h-2.5 rounded-full transition-all duration-500 shadow-sm"
                                  style={{ width: `${progress}%` }}
                                />
                              </div>
                            </div>

                            <div className="flex items-center gap-4 text-sm text-gray-600 mt-3 pt-3 border-t border-gray-100">
                              <div className="flex items-center gap-1.5">
                                <Calendar className="w-4 h-4 text-[#9b2847]" />
                                <span>Última visita: {patient.lastVisit}</span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <Activity className="w-4 h-4 text-[#9b2847]" />
                                <span>{patient.sessions.length} atendimentos</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      <Dialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog({ ...deleteDialog, open })}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <DialogTitle className="text-xl">Confirmar Exclusão</DialogTitle>
                <DialogDescription className="text-gray-600 mt-1">Esta ação não pode ser desfeita</DialogDescription>
              </div>
            </div>
          </DialogHeader>
          <div className="py-4">
            <p className="text-gray-700">
              Tem certeza que deseja excluir o paciente <span className="font-bold">{deleteDialog.patientName}</span>?
            </p>
            <p className="text-sm text-gray-600 mt-2 bg-red-50 p-3 rounded-lg border border-red-100">
              <strong>Atenção:</strong> Todos os dados, histórico de sessões e informações relacionadas serão
              permanentemente removidos do sistema.
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setDeleteDialog({ open: false, patientId: "", patientName: "" })}
              className="bg-transparent"
            >
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleConfirmDelete} className="bg-red-600 hover:bg-red-700">
              <Trash2 className="w-4 h-4 mr-2" />
              Excluir Paciente
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
