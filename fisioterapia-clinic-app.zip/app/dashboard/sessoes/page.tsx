"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { storage } from "@/lib/storage"
import type { Patient, Session } from "@/types/patient"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { ArrowLeft, Search, Users, CheckCircle2, FileText, TrendingUp, Minus, TrendingDown, Eye } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

export default function SessionsPage() {
  const [patients, setPatients] = useState<Patient[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [sessionDialog, setSessionDialog] = useState(false)
  const [completionDialog, setCompletionDialog] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)
  const [sessionData, setSessionData] = useState({
    observation: "",
    evolution: "estavel" as "melhorando" | "estavel" | "declinio",
  })
  const [customSessionCount, setCustomSessionCount] = useState(20)
  const [isAdmin, setIsAdmin] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    if (!storage.isAuthenticated()) {
      router.push("/login")
      return
    }
    setIsAdmin(storage.isAdmin())
    setPatients(storage.getPatients())
  }, [router])

  const filteredPatients = patients.filter((patient) => patient.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const totalPatients = patients.length
  const activeTreatments = patients.filter((p) => p.completedSessions < p.totalSessions).length
  const completed = patients.filter((p) => p.completedSessions >= p.totalSessions).length

  const handleCompleteSession = (patient: Patient) => {
    if (!isAdmin) {
      toast({
        title: "Acesso negado",
        description: "Apenas administradores podem registrar sessões",
        variant: "destructive",
      })
      return
    }
    setSelectedPatient(patient)
    setSessionDialog(true)
    setSessionData({ observation: "", evolution: "estavel" })
  }

  const confirmSession = () => {
    if (!selectedPatient) return

    const newSession: Session = {
      id: Date.now().toString(),
      number: selectedPatient.completedSessions + 1,
      date: new Date().toISOString(),
      time: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      status: "completed",
      observation: sessionData.observation,
      evolution: sessionData.evolution,
      therapist: "Dr. Carlos Mendes",
      type: "Sessão de Fisioterapia",
    }

    const updatedSessions = [...selectedPatient.sessions, newSession]
    const newCompletedCount = selectedPatient.completedSessions + 1

    storage.updatePatient(selectedPatient.id, {
      sessions: updatedSessions,
      completedSessions: newCompletedCount,
      lastVisit: new Date().toLocaleDateString("pt-BR"),
    })

    if (newCompletedCount >= selectedPatient.totalSessions) {
      setSessionDialog(false)
      setCompletionDialog(true)
      setCustomSessionCount(20)
    } else {
      setSessionDialog(false)
      setPatients(storage.getPatients())
      toast({
        title: "Sessão registrada!",
        description: `Sessão ${newCompletedCount} de ${selectedPatient.totalSessions} concluída`,
      })
    }
  }

  const finalizeTreatment = () => {
    if (!selectedPatient) return

    storage.updatePatient(selectedPatient.id, {
      status: "concluido",
    })

    setCompletionDialog(false)
    setSelectedPatient(null)
    setPatients(storage.getPatients())

    toast({
      title: "Tratamento finalizado!",
      description: `O tratamento de ${selectedPatient.name} foi concluído com sucesso`,
    })
  }

  const addMoreSessions = () => {
    if (!selectedPatient) return

    const newTotal = selectedPatient.totalSessions + customSessionCount

    storage.updatePatient(selectedPatient.id, {
      totalSessions: newTotal,
    })

    setCompletionDialog(false)
    setSelectedPatient(null)
    setPatients(storage.getPatients())

    toast({
      title: "Sessões adicionadas!",
      description: `Foram adicionadas ${customSessionCount} sessões. Total: ${newTotal}`,
    })
  }

  const getProgressColor = (progress: number) => {
    if (progress < 33) return "from-red-500 via-orange-500 to-yellow-500"
    if (progress < 66) return "from-yellow-500 via-amber-500 to-orange-400"
    return "from-green-500 via-emerald-500 to-teal-500"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#faf8f5] via-[#f5f1ec] to-[#ede7e0]">
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div className="flex items-center gap-2 ml-4">
              <div className="w-10 h-10 bg-teal-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">Gerenciamento de Sessões</h1>
                <p className="text-sm text-gray-500">Controle de sessões dos pacientes</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Buscar paciente por nome..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 text-base"
            />
          </div>
        </div>

        {!isAdmin && (
          <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Search className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900">Visualização de Sessões</h3>
                <p className="text-sm text-blue-700 mt-1">
                  Você pode visualizar o progresso dos pacientes. Apenas administradores podem registrar novas sessões.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <p className="text-sm text-gray-600">Total de Pacientes</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{totalPatients}</p>
              </div>
              <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <p className="text-sm text-gray-600">Tratamentos Ativos</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{activeTreatments}</p>
              </div>
              <div className="w-12 h-12 bg-teal-500 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <p className="text-sm text-gray-600">Concluídos</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{completed}</p>
              </div>
              <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Patients List */}
        {filteredPatients.length === 0 ? (
          <Card className="shadow-lg border-0">
            <CardContent className="py-12">
              <div className="text-center text-gray-500">
                <Users className="w-16 h-16 mx-auto mb-4 opacity-30" />
                <p className="text-lg font-medium">Nenhum paciente encontrado</p>
                <p className="text-sm mt-1">
                  {searchTerm ? "Tente buscar com outro termo" : "Não há pacientes cadastrados"}
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredPatients.map((patient) => {
              const progress = (patient.completedSessions / patient.totalSessions) * 100
              const isCompleted = patient.completedSessions >= patient.totalSessions

              return (
                <Card key={patient.id} className="shadow-lg border-0 hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">{patient.name}</h3>
                        <p className="text-sm text-gray-500 mt-1">Última sessão: {patient.lastVisit}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-4xl font-bold text-teal-600">
                          {patient.completedSessions}{" "}
                          <span className="text-2xl text-gray-400">/ {patient.totalSessions}</span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">sessões completas</p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex justify-between text-sm text-gray-600 mb-2">
                        <span className="font-medium">Progresso do Tratamento</span>
                        <span className="font-semibold">{Math.round(progress)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-4 shadow-inner">
                        <div
                          className={`bg-gradient-to-r ${getProgressColor(progress)} h-4 rounded-full transition-all duration-500 shadow-lg`}
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>

                    {/* Session Indicators */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {Array.from({ length: patient.totalSessions }).map((_, index) => (
                        <div
                          key={index}
                          className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                            index < patient.completedSessions
                              ? "bg-gradient-to-br from-teal-500 to-teal-600 text-white shadow-md"
                              : "bg-gray-200 text-gray-400"
                          }`}
                        >
                          {index < patient.completedSessions ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            <span className="text-[10px]">{index + 1}</span>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3 pt-4 border-t">
                      <Link href={`/dashboard/paciente/${patient.id}`} className="flex-1">
                        <Button
                          variant="outline"
                          className="w-full bg-white border-[#9b2847] text-[#9b2847] hover:bg-[#9b2847] hover:text-white"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Ver Detalhes
                        </Button>
                      </Link>
                      {isCompleted ? (
                        <Button disabled className="flex-1 bg-green-600 text-white">
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Tratamento Concluído
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleCompleteSession(patient)}
                          disabled={!isAdmin}
                          className={`flex-1 ${!isAdmin ? "bg-gray-400 cursor-not-allowed" : "bg-[#9b2847] hover:bg-[#7a1f38]"}`}
                        >
                          <FileText className="w-4 h-4 mr-2" />
                          {isAdmin ? "Completar Sessão" : "Somente Admin"}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </main>

      <Dialog open={sessionDialog} onOpenChange={setSessionDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Registrar Sessão</DialogTitle>
            <DialogDescription>Adicione observações sobre a sessão de {selectedPatient?.name}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Status de Evolução</Label>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  type="button"
                  variant={sessionData.evolution === "melhorando" ? "default" : "outline"}
                  onClick={() => setSessionData({ ...sessionData, evolution: "melhorando" })}
                  className={sessionData.evolution === "melhorando" ? "bg-green-600 hover:bg-green-700" : ""}
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Melhorando
                </Button>
                <Button
                  type="button"
                  variant={sessionData.evolution === "estavel" ? "default" : "outline"}
                  onClick={() => setSessionData({ ...sessionData, evolution: "estavel" })}
                  className={sessionData.evolution === "estavel" ? "bg-blue-600 hover:bg-blue-700" : ""}
                >
                  <Minus className="w-4 h-4 mr-2" />
                  Estável
                </Button>
                <Button
                  type="button"
                  variant={sessionData.evolution === "declinio" ? "default" : "outline"}
                  onClick={() => setSessionData({ ...sessionData, evolution: "declinio" })}
                  className={sessionData.evolution === "declinio" ? "bg-orange-600 hover:bg-orange-700" : ""}
                >
                  <TrendingDown className="w-4 h-4 mr-2" />
                  Declínio
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="observation">Observações</Label>
              <Textarea
                id="observation"
                placeholder="Descreva o progresso e detalhes da sessão..."
                value={sessionData.observation}
                onChange={(e) => setSessionData({ ...sessionData, observation: e.target.value })}
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setSessionDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmSession} className="bg-teal-600 hover:bg-teal-700">
              Confirmar Sessão
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={completionDialog} onOpenChange={setCompletionDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Tratamento Completo</DialogTitle>
            <DialogDescription>
              {selectedPatient?.name} completou todas as {selectedPatient?.totalSessions} sessões programadas.
            </DialogDescription>
          </DialogHeader>

          <div className="py-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="renewalCount" className="text-center block">
                  Quantas sessões deseja adicionar?
                </Label>
                <Input
                  id="renewalCount"
                  type="number"
                  min="1"
                  max="100"
                  value={customSessionCount}
                  onChange={(e) => setCustomSessionCount(Number.parseInt(e.target.value) || 0)}
                  className="text-center text-lg font-semibold"
                />
                <p className="text-xs text-muted-foreground text-center">
                  O paciente terá {(selectedPatient?.totalSessions || 0) + customSessionCount} sessões no total
                </p>
              </div>
            </div>
          </div>

          <DialogFooter className="flex-col sm:flex-col gap-2">
            <Button onClick={addMoreSessions} className="w-full bg-teal-600 hover:bg-teal-700">
              Renovar Tratamento
            </Button>
            <Button onClick={finalizeTreatment} variant="outline" className="w-full bg-transparent">
              Finalizar Tratamento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
