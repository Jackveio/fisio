"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { storage } from "@/lib/storage"
import type { Patient } from "@/types/patient"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import {
  Users,
  Calendar,
  Clock,
  TrendingUp,
  UserPlus,
  ClipboardList,
  History,
  LogOut,
  Eye,
  Download,
  Upload,
} from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { IntegralClinicaLogo } from "@/components/logo"
import { useToast } from "@/hooks/use-toast"
import { Input } from "@/components/ui/input"

export default function DashboardPage() {
  const [patients, setPatients] = useState<Patient[]>([])
  const [currentUser, setCurrentUser] = useState<{ name: string; role: string } | null>(null)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    if (!storage.isAuthenticated()) {
      router.push("/login")
      return
    }
    const user = storage.getCurrentUser()
    setCurrentUser(user)
    setPatients(storage.getPatients())
  }, [router])

  const handleLogout = () => {
    storage.logout()
    router.push("/login")
  }

  const handleExportData = () => {
    try {
      storage.exportData()
      toast({
        title: "Dados exportados com sucesso!",
        description: "O arquivo foi baixado para seu computador.",
      })
    } catch (error) {
      toast({
        title: "Erro ao exportar dados",
        description: "Ocorreu um erro ao exportar os dados.",
        variant: "destructive",
      })
    }
  }

  const handleImportData = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const result = await storage.importData(file)

    if (result.success) {
      toast({
        title: "Dados importados com sucesso!",
        description: result.message,
      })
      setPatients(storage.getPatients())
    } else {
      toast({
        title: "Erro ao importar dados",
        description: result.message,
        variant: "destructive",
      })
    }

    e.target.value = ""
  }

  const totalPatients = patients.length
  const today = new Date().toLocaleDateString("pt-BR")
  const consultasHoje = patients.filter((p) => p.nextAppointment === today).length
  const pendentes = patients.filter((p) => p.status === "pendente").length
  const completionRate =
    patients.length > 0
      ? Math.round(
          (patients.reduce((acc, p) => acc + p.completedSessions, 0) /
            patients.reduce((acc, p) => acc + p.totalSessions, 0)) *
            100,
        )
      : 94

  const recentPatients = patients.slice(0, 5)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ativo":
        return (
          <Badge className="bg-gradient-to-r from-green-100 to-green-200 text-green-800 border-green-300 hover:from-green-200 hover:to-green-300">
            Ativo
          </Badge>
        )
      case "pendente":
        return (
          <Badge className="bg-gradient-to-r from-orange-100 to-orange-200 text-orange-800 border-orange-300 hover:from-orange-200 hover:to-orange-300">
            Pendente
          </Badge>
        )
      case "concluido":
        return (
          <Badge className="bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 border-blue-300 hover:from-blue-200 hover:to-blue-300">
            Concluído
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const isAdmin = currentUser?.role === "admin"

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#faf8f5] via-[#f5f1ec] to-[#ede7e0]">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <IntegralClinicaLogo className="w-48 h-12" />
            </div>
            <div className="flex items-center gap-3">
              {isAdmin && (
                <>
                  <Button
                    variant="outline"
                    onClick={handleExportData}
                    className="bg-green-50 border-green-200 text-green-700 hover:bg-green-100 hover:border-green-300"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Exportar Dados
                  </Button>
                  <label htmlFor="import-file">
                    <Button
                      variant="outline"
                      className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300"
                      onClick={() => document.getElementById("import-file")?.click()}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Importar Dados
                    </Button>
                  </label>
                  <Input id="import-file" type="file" accept=".json" className="hidden" onChange={handleImportData} />
                </>
              )}
              {currentUser && (
                <div className="text-right mr-2">
                  <p className="text-sm font-semibold text-gray-900">{currentUser.name}</p>
                  <p className="text-xs text-gray-500 capitalize">
                    {currentUser.role === "admin" ? "Administrador" : "Usuário"}
                  </p>
                </div>
              )}
              <Button
                variant="outline"
                onClick={handleLogout}
                className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100 hover:border-red-300"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-lg border-0 overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="h-2 bg-gradient-to-r from-blue-500 to-cyan-500" />
            <CardHeader className="flex flex-row items-center justify-between pb-2 bg-gradient-to-br from-blue-50 to-white">
              <div>
                <p className="text-sm font-medium text-gray-600">Total de Pacientes</p>
                <p className="text-4xl font-bold text-gray-900 mt-2">{totalPatients}</p>
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                <Users className="w-7 h-7 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card className="shadow-lg border-0 overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="h-2 bg-gradient-to-r from-teal-500 to-green-500" />
            <CardHeader className="flex flex-row items-center justify-between pb-2 bg-gradient-to-br from-teal-50 to-white">
              <div>
                <p className="text-sm font-medium text-gray-600">Consultas Hoje</p>
                <p className="text-4xl font-bold text-gray-900 mt-2">{consultasHoje}</p>
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
                <Calendar className="w-7 h-7 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card className="shadow-lg border-0 overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="h-2 bg-gradient-to-r from-orange-500 to-amber-500" />
            <CardHeader className="flex flex-row items-center justify-between pb-2 bg-gradient-to-br from-orange-50 to-white">
              <div>
                <p className="text-sm font-medium text-gray-600">Pendentes</p>
                <p className="text-4xl font-bold text-gray-900 mt-2">{pendentes}</p>
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
                <Clock className="w-7 h-7 text-white" />
              </div>
            </CardHeader>
          </Card>

          <Card className="shadow-lg border-0 overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="h-2 bg-gradient-to-r from-green-500 to-emerald-500" />
            <CardHeader className="flex flex-row items-center justify-between pb-2 bg-gradient-to-br from-green-50 to-white">
              <div>
                <p className="text-sm font-medium text-gray-600">Taxa de Conclusão</p>
                <p className="text-4xl font-bold text-gray-900 mt-2">{completionRate}%</p>
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                <TrendingUp className="w-7 h-7 text-white" />
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Action Buttons */}
        {!isAdmin && (
          <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Eye className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900">Modo de Visualização</h3>
                <p className="text-sm text-blue-700 mt-1">
                  Você está acessando o sistema em modo somente leitura. Apenas administradores podem cadastrar, editar
                  ou excluir informações.
                </p>
              </div>
            </div>
          </div>
        )}

        {isAdmin && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Link href="/dashboard/novo-paciente">
              <Card className="h-28 cursor-pointer hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
                <div className="h-full bg-gradient-to-br from-[#9b2847] to-[#b8385d] hover:from-[#7a1f38] hover:to-[#9b2847] transition-all duration-300">
                  <CardContent className="h-full flex items-center justify-center gap-4 p-6">
                    <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <UserPlus className="w-7 h-7 text-white" />
                    </div>
                    <span className="text-xl font-bold text-white">Novo Paciente</span>
                  </CardContent>
                </div>
              </Card>
            </Link>

            <Link href="/dashboard/sessoes">
              <Card className="h-28 cursor-pointer hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
                <div className="h-full bg-gradient-to-br from-[#b8385d] to-[#c54a6f] hover:from-[#9b2847] hover:to-[#b8385d] transition-all duration-300">
                  <CardContent className="h-full flex items-center justify-center gap-4 p-6">
                    <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <ClipboardList className="w-7 h-7 text-white" />
                    </div>
                    <span className="text-xl font-bold text-white">Gerenciar Sessões</span>
                  </CardContent>
                </div>
              </Card>
            </Link>

            <Link href="/dashboard/historico">
              <Card className="h-28 cursor-pointer hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
                <div className="h-full bg-gradient-to-br from-[#6b7280] to-[#4b5563] hover:from-[#4b5563] hover:to-[#374151] transition-all duration-300">
                  <CardContent className="h-full flex items-center justify-center gap-4 p-6">
                    <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <History className="w-7 h-7 text-white" />
                    </div>
                    <span className="text-xl font-bold text-white">Histórico</span>
                  </CardContent>
                </div>
              </Card>
            </Link>
          </div>
        )}

        {!isAdmin && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Link href="/dashboard/historico">
              <Card className="h-28 cursor-pointer hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
                <div className="h-full bg-gradient-to-br from-[#6b7280] to-[#4b5563] hover:from-[#4b5563] hover:to-[#374151] transition-all duration-300">
                  <CardContent className="h-full flex items-center justify-center gap-4 p-6">
                    <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <History className="w-7 h-7 text-white" />
                    </div>
                    <span className="text-xl font-bold text-white">Ver Histórico</span>
                  </CardContent>
                </div>
              </Card>
            </Link>

            <Link href="/dashboard/sessoes">
              <Card className="h-28 cursor-pointer hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group">
                <div className="h-full bg-gradient-to-br from-[#b8385d] to-[#c54a6f] hover:from-[#9b2847] hover:to-[#b8385d] transition-all duration-300">
                  <CardContent className="h-full flex items-center justify-center gap-4 p-6">
                    <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <ClipboardList className="w-7 h-7 text-white" />
                    </div>
                    <span className="text-xl font-bold text-white">Ver Sessões</span>
                  </CardContent>
                </div>
              </Card>
            </Link>
          </div>
        )}

        {/* Recent Patients Table */}
        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-gray-700 to-gray-800 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-gray-900">Pacientes Recentes</h2>
                  <p className="text-sm text-gray-600">Últimos pacientes atendidos na clínica</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {recentPatients.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-10 h-10 text-gray-400" />
                </div>
                <p className="text-lg font-medium text-gray-500">Nenhum paciente cadastrado</p>
                <p className="text-sm text-gray-400 mt-1">Cadastre seu primeiro paciente para começar</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="text-left py-4 px-6 text-sm font-bold text-gray-700 uppercase tracking-wide">
                        Nome Completo
                      </th>
                      <th className="text-left py-4 px-6 text-sm font-bold text-gray-700 uppercase tracking-wide">
                        Última Visita
                      </th>
                      <th className="text-left py-4 px-6 text-sm font-bold text-gray-700 uppercase tracking-wide">
                        Próxima Consulta
                      </th>
                      <th className="text-left py-4 px-6 text-sm font-bold text-gray-700 uppercase tracking-wide">
                        Status
                      </th>
                      <th className="text-left py-4 px-6 text-sm font-bold text-gray-700 uppercase tracking-wide">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {recentPatients.map((patient) => (
                      <tr key={patient.id} className="hover:bg-blue-50/50 transition-colors duration-150">
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-teal-400 to-teal-500 rounded-lg flex items-center justify-center">
                              <span className="text-white font-bold text-sm">{patient.name.charAt(0)}</span>
                            </div>
                            <span className="font-semibold text-gray-900">{patient.name}</span>
                          </div>
                        </td>
                        <td className="py-4 px-6 text-sm text-gray-600">{patient.lastVisit || "14/01/2024"}</td>
                        <td className="py-4 px-6 text-sm text-gray-600">{patient.nextAppointment || "21/01/2024"}</td>
                        <td className="py-4 px-6">{getStatusBadge(patient.status || "ativo")}</td>
                        <td className="py-4 px-6">
                          <Link href={`/dashboard/paciente/${patient.id}`}>
                            <Button
                              variant="outline"
                              size="sm"
                              className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300"
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              Ver Detalhes
                            </Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
