"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, User, Phone, FileText, Mail, MapPin, Calendar, Hash, Save, X, AlertCircle } from "lucide-react"
import Link from "next/link"
import { storage } from "@/lib/storage"
import type { Patient } from "@/types/patient"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function NewPatientPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [errors, setErrors] = useState<{ field: string; message: string }[]>([])
  const [formData, setFormData] = useState({
    name: "",
    cpf: "",
    birthDate: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "UF",
    cep: "",
    clinicalObservations: "",
    totalSessions: "20",
  })

  const validateForm = (): boolean => {
    const newErrors: { field: string; message: string }[] = []

    if (formData.name.trim().length < 3) {
      newErrors.push({ field: "name", message: "Nome deve ter pelo menos 3 caracteres" })
    }

    const cpfNumbers = formData.cpf.replace(/\D/g, "")
    if (cpfNumbers.length !== 11) {
      newErrors.push({ field: "cpf", message: "CPF deve conter 11 dígitos" })
    }

    const phoneNumbers = formData.phone.replace(/\D/g, "")
    if (phoneNumbers.length < 10) {
      newErrors.push({ field: "phone", message: "Telefone deve conter pelo menos 10 dígitos" })
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.push({ field: "email", message: "E-mail inválido" })
    }

    if (!formData.birthDate) {
      newErrors.push({ field: "birthDate", message: "Data de nascimento é obrigatória" })
    }

    const sessions = Number.parseInt(formData.totalSessions)
    if (sessions < 1 || sessions > 100) {
      newErrors.push({ field: "totalSessions", message: "Número de sessões deve ser entre 1 e 100" })
    }

    setErrors(newErrors)
    return newErrors.length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Dados inválidos",
        description: "Por favor, corrija os erros no formulário",
        variant: "destructive",
      })
      return
    }

    const newPatient: Patient = {
      id: Date.now().toString(),
      ...formData,
      totalSessions: Number.parseInt(formData.totalSessions) || 20,
      completedSessions: 0,
      sessions: [],
      status: "ativo",
      lastVisit: new Date().toLocaleDateString("pt-BR"),
      nextAppointment: new Date().toLocaleDateString("pt-BR"),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    try {
      storage.addPatient(newPatient)

      toast({
        title: "Paciente cadastrado com sucesso!",
        description: `${formData.name} foi adicionado ao sistema com ${formData.totalSessions} sessões`,
      })

      router.push("/dashboard")
    } catch (error) {
      if (error instanceof Error && error.message === "CPF_DUPLICATE") {
        setErrors([{ field: "cpf", message: "Este CPF já está cadastrado no sistema" }])
        toast({
          title: "CPF duplicado",
          description: "Já existe um paciente cadastrado com este CPF",
          variant: "destructive",
        })
      } else {
        toast({
          title: "Erro ao cadastrar",
          description: "Ocorreu um erro ao cadastrar o paciente. Tente novamente.",
          variant: "destructive",
        })
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900 hover:bg-teal-50">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="h-8 w-px bg-gray-300" />
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-lg font-bold text-gray-900">Cadastrar Novo Paciente</h1>
                  <p className="text-sm text-gray-500">Preencha os dados do paciente para cadastro</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        {errors.length > 0 && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Erro no formulário</AlertTitle>
            <AlertDescription>
              <ul className="list-disc list-inside space-y-1 mt-2">
                {errors.map((error, index) => (
                  <li key={index}>{error.message}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card className="shadow-lg border-0 overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500" />
            <CardHeader className="bg-gradient-to-br from-blue-50 to-cyan-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center shadow-md">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-lg text-gray-900">Dados Pessoais</CardTitle>
                  <CardDescription className="text-gray-600">Informações básicas do paciente</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                  <User className="w-4 h-4 text-blue-600" />
                  Nome Completo *
                </Label>
                <Input
                  id="name"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Digite o nome completo do paciente"
                  className="h-12 text-base border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cpf" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <Hash className="w-4 h-4 text-blue-600" />
                    CPF *
                  </Label>
                  <Input
                    id="cpf"
                    required
                    value={formData.cpf}
                    onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
                    placeholder="000.000.000-00"
                    className="h-12 text-base border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="birthDate" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-blue-600" />
                    Data de Nascimento *
                  </Label>
                  <Input
                    id="birthDate"
                    type="date"
                    required
                    value={formData.birthDate}
                    onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                    className="h-12 text-base border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="totalSessions" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  Número de Sessões *
                </Label>
                <Input
                  id="totalSessions"
                  type="number"
                  required
                  min="1"
                  max="100"
                  value={formData.totalSessions}
                  onChange={(e) => setFormData({ ...formData, totalSessions: e.target.value })}
                  placeholder="20"
                  className="h-12 text-base border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-500 flex items-center gap-1.5 bg-blue-50 px-3 py-2 rounded-md">
                  <svg className="w-3.5 h-3.5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                      clipRule="evenodd"
                    />
                  </svg>
                  Defina o número total de sessões para este paciente (1 a 100)
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-teal-500 via-green-500 to-emerald-500" />
            <CardHeader className="bg-gradient-to-br from-teal-50 to-green-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center shadow-md">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-lg text-gray-900">Informações de Contato</CardTitle>
                  <CardDescription className="text-gray-600">Telefone, e-mail e endereço</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-teal-600" />
                    Telefone *
                  </Label>
                  <Input
                    id="phone"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="(00) 00000-0000"
                    className="h-12 text-base border-gray-300 focus:border-teal-500 focus:ring-teal-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <Mail className="w-4 h-4 text-teal-600" />
                    E-mail
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="exemplo@email.com"
                    className="h-12 text-base border-gray-300 focus:border-teal-500 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-teal-600" />
                  Endereço Completo
                </Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Rua, número, complemento"
                  className="h-12 text-base border-gray-300 focus:border-teal-500 focus:ring-teal-500"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city" className="text-sm font-semibold text-gray-700">
                    Cidade
                  </Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Digite a cidade"
                    className="h-12 text-base border-gray-300 focus:border-teal-500 focus:ring-teal-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state" className="text-sm font-semibold text-gray-700">
                    Estado
                  </Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value.toUpperCase() })}
                    placeholder="UF"
                    maxLength={2}
                    className="h-12 text-base border-gray-300 focus:border-teal-500 focus:ring-teal-500 uppercase"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cep" className="text-sm font-semibold text-gray-700">
                    CEP
                  </Label>
                  <Input
                    id="cep"
                    value={formData.cep}
                    onChange={(e) => setFormData({ ...formData, cep: e.target.value })}
                    placeholder="00000-000"
                    className="h-12 text-base border-gray-300 focus:border-teal-500 focus:ring-teal-500"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500" />
            <CardHeader className="bg-gradient-to-br from-purple-50 to-pink-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center shadow-md">
                  <FileText className="w-5 h-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-lg text-gray-900">Observações Clínicas</CardTitle>
                  <CardDescription className="text-gray-600">Informações adicionais relevantes</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-2">
                <Label htmlFor="observations" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-600" />
                  Observações
                </Label>
                <Textarea
                  id="observations"
                  value={formData.clinicalObservations}
                  onChange={(e) => setFormData({ ...formData, clinicalObservations: e.target.value })}
                  placeholder="Digite quaisquer observações importantes sobre o paciente, histórico médico, medicações em uso, limitações físicas, etc."
                  rows={5}
                  className="resize-none text-base border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                />
                <p className="text-xs text-gray-500 bg-purple-50 px-3 py-2 rounded-md">
                  Inclua informações sobre histórico médico, alergias, medicações ou qualquer observação relevante
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-4 pt-4">
            <Link href="/dashboard" className="flex-1">
              <Button
                type="button"
                variant="outline"
                className="w-full h-14 text-base font-medium bg-white border-2 border-gray-300 hover:bg-gray-50 hover:border-gray-400"
              >
                <X className="w-5 h-5 mr-2" />
                Cancelar
              </Button>
            </Link>
            <Button
              type="submit"
              className="flex-1 h-14 bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white text-base font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <Save className="w-5 h-5 mr-2" />
              Cadastrar Paciente
            </Button>
          </div>
        </form>
      </main>
    </div>
  )
}
