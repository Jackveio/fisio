"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Phone, Mail, MapPin, Calendar, Edit, Trash2, MessageCircle, Minus, User, Eye } from "lucide-react"
import Link from "next/link"
import { storage } from "@/lib/storage"
import type { Patient } from "@/types/patient"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Label } from "@/components/ui/label"

export default function PatientDetailPage() {
  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()
  const [patient, setPatient] = useState<Patient | null>(null)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    if (!storage.isAuthenticated()) {
      router.push("/login")
      return
    }

    setIsAdmin(storage.isAdmin())

    const id = params.id as string
    const foundPatient = storage.getPatient(id)
    if (foundPatient) {
      setPatient(foundPatient)
    } else {
      router.push("/dashboard")
    }
  }, [router, params.id])

  const handleAddSession = () => {
    if (!patient || !isAdmin) return

    storage.updatePatient(patient.id, {
      totalSessions: patient.totalSessions + 1,
    })

    toast({
      title: "Sessão adicionada",
      description: "Uma sessão foi adicionada ao tratamento",
    })

    const updatedPatient = storage.getPatient(patient.id)
    if (updatedPatient) setPatient(updatedPatient)
  }

  const handleRemoveSession = () => {
    if (!patient || !isAdmin) return

    if (patient.totalSessions <= 1) {
      toast({
        title: "Erro",
        description: "O paciente deve ter pelo menos 1 sessão",
        variant: "destructive",
      })
      return
    }

    if (patient.completedSessions >= patient.totalSessions - 1) {
      toast({
        title: "Erro",
        description: "Não é possível remover sessões. Complete menos sessões primeiro.",
        variant: "destructive",
      })
      return
    }

    storage.updatePatient(patient.id, {
      totalSessions: patient.totalSessions - 1,
    })

    toast({
      title: "Sessão removida",
      description: "Uma sessão foi removida do tratamento",
    })

    const updatedPatient = storage.getPatient(patient.id)
    if (updatedPatient) setPatient(updatedPatient)
  }

  const handleDelete = () => {
    if (!patient || !isAdmin) return

    storage.deletePatient(patient.id)

    toast({
      title: "Paciente excluído",
      description: "O paciente foi removido do sistema",
    })

    router.push("/dashboard")
  }

  const sendWhatsApp = () => {
    if (!patient) return

    const phone = patient.phone.replace(/\D/g, "")
    const message = encodeURIComponent(`Olá ${patient.name}, aqui é da Integral Clínica. Como você está?`)
    window.open(`https://wa.me/55${phone}?text=${message}`, "_blank")
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const getProgressColor = (progress: number) => {
    if (progress < 33) return "from-red-500 to-orange-500"
    if (progress < 66) return "from-yellow-500 to-amber-500"
    return "from-green-500 to-teal-500"
  }

  if (!patient) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    )
  }

  const progress = (patient.completedSessions / patient.totalSessions) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#faf8f5] via-[#f5f1ec] to-[#ede7e0]">
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="hover:bg-teal-50">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Dashboard
            </Button>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {!isAdmin && (
          <div className="mb-6 bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Eye className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900">Modo de Visualização</h3>
                <p className="text-sm text-blue-700 mt-1">
                  Você está visualizando os dados do paciente. Apenas administradores podem editar ou excluir.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="shadow-lg border-0 overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-[#9b2847] via-[#b8385d] to-[#c54a6f]" />
              <CardHeader className="bg-gradient-to-br from-white to-[#faf8f5]">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-[#9b2847] to-[#b8385d] rounded-2xl flex items-center justify-center shadow-lg">
                      <User className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl font-bold text-gray-900">{patient.name}</CardTitle>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-sm text-gray-500">CPF:</span>
                        <span className="text-sm font-medium text-gray-700">{patient.cpf}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={sendWhatsApp}
                      className="bg-green-50 border-green-200 text-green-700 hover:bg-green-100 hover:border-green-300"
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      WhatsApp
                    </Button>
                    {isAdmin && (
                      <>
                        <Link href={`/dashboard/paciente/${patient.id}/editar`}>
                          <Button
                            variant="outline"
                            size="sm"
                            className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300"
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Editar
                          </Button>
                        </Link>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setShowDeleteDialog(true)}
                          className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100 hover:border-red-300"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Excluir
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-100">
                    <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Telefone</p>
                      <p className="font-semibold text-gray-900 mt-1">{patient.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-100">
                    <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">E-mail</p>
                      <p className="font-semibold text-gray-900 mt-1 truncate">{patient.email || "Não informado"}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-br from-green-50 to-emerald-50 border border-green-100">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Calendar className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Data de Nascimento</p>
                      <p className="font-semibold text-gray-900 mt-1">{formatDate(patient.birthDate)}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-br from-orange-50 to-amber-50 border border-orange-100">
                    <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Endereço</p>
                      <p className="font-semibold text-gray-900 mt-1">{patient.address || "Não informado"}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0">
              <CardHeader className="bg-gradient-to-r from-teal-50 to-blue-50 border-b">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Histórico de Sessões</CardTitle>
                    <CardDescription className="text-sm">{patient.sessions.length} sessões registradas</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                {patient.sessions.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Calendar className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-gray-500 font-medium">Nenhuma sessão registrada ainda</p>
                    <p className="text-sm text-gray-400 mt-1">As sessões aparecerão aqui após serem registradas</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {patient.sessions
                      .slice()
                      .reverse()
                      .map((session, index) => (
                        <Card
                          key={session.id}
                          className="border-l-4 hover:shadow-md transition-all duration-200"
                          style={{
                            borderLeftColor:
                              session.evolution === "melhorando"
                                ? "#10b981"
                                : session.evolution === "estavel"
                                  ? "#3b82f6"
                                  : "#f97316",
                          }}
                        >
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-3">
                                <div
                                  className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                                    session.evolution === "melhorando"
                                      ? "bg-green-100"
                                      : session.evolution === "estavel"
                                        ? "bg-blue-100"
                                        : "bg-orange-100"
                                  }`}
                                >
                                  <span
                                    className={`text-sm font-bold ${
                                      session.evolution === "melhorando"
                                        ? "text-green-700"
                                        : session.evolution === "estavel"
                                          ? "text-blue-700"
                                          : "text-orange-700"
                                    }`}
                                  >
                                    #{session.number}
                                  </span>
                                </div>
                                <div>
                                  <h4 className="font-semibold text-gray-900">Sessão {session.number}</h4>
                                  <p className="text-sm text-gray-500">{formatDate(session.date)}</p>
                                </div>
                              </div>
                              {session.evolution && (
                                <span
                                  className={`text-xs px-3 py-1.5 rounded-full font-semibold flex items-center gap-1.5 ${
                                    session.evolution === "melhorando"
                                      ? "bg-green-100 text-green-700"
                                      : session.evolution === "estavel"
                                        ? "bg-blue-100 text-blue-700"
                                        : "bg-orange-100 text-orange-700"
                                  }`}
                                >
                                  {session.evolution === "melhorando" ? (
                                    <>
                                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                        <path
                                          fillRule="evenodd"
                                          d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z"
                                          clipRule="evenodd"
                                        />
                                      </svg>
                                      Melhorando
                                    </>
                                  ) : session.evolution === "estavel" ? (
                                    <>
                                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                        <path
                                          fillRule="evenodd"
                                          d="M3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                                          clipRule="evenodd"
                                        />
                                      </svg>
                                      Estável
                                    </>
                                  ) : (
                                    <>
                                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                        <path
                                          fillRule="evenodd"
                                          d="M14.707 12.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l2.293-2.293a1 1 0 011.414 0z"
                                          clipRule="evenodd"
                                        />
                                      </svg>
                                      Declínio
                                    </>
                                  )}
                                </span>
                              )}
                            </div>
                            {session.observation && (
                              <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
                                <p className="text-sm text-gray-700">{session.observation}</p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="shadow-lg border-0 overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-[#9b2847] via-[#b8385d] to-[#c54a6f]" />
              <CardHeader className="bg-gradient-to-br from-teal-50 to-blue-50">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-teal-500 rounded-lg flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                      />
                    </svg>
                  </div>
                  <CardTitle className="text-lg">Progresso do Tratamento</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="text-center mb-6">
                  <div className="relative inline-block">
                    <div className="text-6xl font-bold bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent mb-2">
                      {patient.completedSessions}
                      <span className="text-3xl text-gray-400">/{patient.totalSessions}</span>
                    </div>
                    <p className="text-sm text-gray-600 font-medium">sessões realizadas</p>
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 font-medium">Progresso Geral</span>
                    <span className="font-bold text-gray-900">{Math.round(progress)}%</span>
                  </div>
                  <div className="relative bg-gray-200 rounded-full h-5 shadow-inner overflow-hidden">
                    <div
                      className={`bg-gradient-to-r ${getProgressColor(progress)} h-5 rounded-full transition-all duration-700 ease-out relative overflow-hidden`}
                      style={{ width: `${progress}%` }}
                    >
                      <div className="absolute inset-0 bg-white/20 animate-pulse" />
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                  <div className="flex justify-between items-center p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                    <span className="text-sm text-blue-900 font-medium flex items-center gap-2">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                        <path
                          fillRule="evenodd"
                          d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z"
                          clipRule="evenodd"
                        />
                      </svg>
                      Total de sessões
                    </span>
                    <span className="font-bold text-blue-900 text-lg">{patient.totalSessions}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gradient-to-r from-green-50 to-green-100 rounded-lg border border-green-200">
                    <span className="text-sm text-green-900 font-medium flex items-center gap-2">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                      Realizadas
                    </span>
                    <span className="font-bold text-green-900 text-lg">{patient.completedSessions}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg border border-orange-200">
                    <span className="text-sm text-orange-900 font-medium flex items-center gap-2">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path
                          fillRule="evenodd"
                          d="M11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"
                          clipRule="evenodd"
                        />
                      </svg>
                      Restantes
                    </span>
                    <span className="font-bold text-orange-900 text-lg">
                      {patient.totalSessions - patient.completedSessions}
                    </span>
                  </div>
                </div>

                {isAdmin && (
                  <div className="space-y-3 pt-4 border-t border-gray-200">
                    <Label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <svg className="w-4 h-4 text-teal-600" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                      </svg>
                      Gerenciar Sessões
                    </Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleRemoveSession}
                        disabled={patient.totalSessions <= 1 || patient.completedSessions >= patient.totalSessions - 1}
                        className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100 hover:border-red-300 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Minus className="w-4 h-4 mr-2" />
                        Remover
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleAddSession}
                        className="bg-teal-50 border-teal-200 text-teal-700 hover:bg-teal-100 hover:border-teal-300"
                      >
                        <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                          <path
                            fillRule="evenodd"
                            d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 01-2 0v-5H4a1 1 0 010-2h5V4a1 1 0 011-1z"
                            clipRule="evenodd"
                          />
                        </svg>
                        Adicionar
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 text-center bg-gray-50 p-2 rounded">
                      Gerencie o número total de sessões do tratamento
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div>
                    <CardTitle className="text-lg">Informações do Cadastro</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 pt-4">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className="text-sm text-gray-600">Data de cadastro</span>
                  <span className="font-semibold text-gray-900">{formatDate(patient.createdAt)}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className="text-sm text-gray-600">Última atualização</span>
                  <span className="font-semibold text-gray-900">{formatDate(patient.updatedAt)}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6 text-red-600" />
            </div>
            <DialogTitle className="text-center text-xl">Confirmar Exclusão</DialogTitle>
            <DialogDescription className="text-center">
              Tem certeza que deseja excluir o paciente <strong className="text-gray-900">{patient.name}</strong>?
              <br />
              <span className="text-red-600 font-medium">Esta ação não pode ser desfeita</span> e todos os dados do
              paciente serão permanentemente removidos.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col sm:flex-row gap-2 mt-4">
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)} className="flex-1 bg-transparent">
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDelete} className="flex-1 bg-red-600 hover:bg-red-700">
              <Trash2 className="w-4 h-4 mr-2" />
              Sim, Excluir Paciente
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
