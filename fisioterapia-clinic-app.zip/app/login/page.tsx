"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { storage } from "@/lib/storage"
import { useToast } from "@/hooks/use-toast"
import { Lock, Mail, Shield, User } from "lucide-react"
import { IntegralClinicaLogo } from "@/components/logo"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (storage.login(email, password)) {
      const user = storage.getCurrentUser()
      toast({
        title: "Login realizado com sucesso!",
        description: `Bem-vindo, ${user?.name || "Usuário"}`,
      })
      router.push("/dashboard")
    } else {
      toast({
        title: "Erro no login",
        description: "Email ou senha incorretos",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#faf8f5] via-[#f5f1ec] to-[#ede7e0] p-4">
      <Card className="w-full max-w-md shadow-2xl border-0">
        <CardHeader className="text-center space-y-4 pb-8">
          <div className="flex justify-center mb-2">
            <IntegralClinicaLogo className="w-56 h-16" />
          </div>
          <CardDescription className="text-base text-gray-600">Sistema de Gestão de Pacientes</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#9b2847]" />
                Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#9b2847]" />
                Senha
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-11"
              />
            </div>
            <Button
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-[#9b2847] to-[#b8385d] hover:from-[#7a1f38] hover:to-[#9b2847] text-white font-medium text-base shadow-lg"
            >
              Entrar
            </Button>

            <div className="mt-6 space-y-3">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-blue-600" />
                  <p className="text-sm font-semibold text-blue-900">Admin (Acesso Total):</p>
                </div>
                <p className="text-xs text-blue-700">Email: admin@clinica.com</p>
                <p className="text-xs text-blue-700">Senha: admin123</p>
              </div>

              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <User className="w-4 h-4 text-green-600" />
                  <p className="text-sm font-semibold text-green-900">Usuário (Visualização):</p>
                </div>
                <p className="text-xs text-green-700">Email: usuario@clinica.com</p>
                <p className="text-xs text-green-700">Senha: user123</p>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
